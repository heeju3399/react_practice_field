function Component(props) {
  debugger;
  if (props.cond) {
    debugger;
  } else {
    while (props.cond) {
      debugger;
    }
  }
  debugger;
}
