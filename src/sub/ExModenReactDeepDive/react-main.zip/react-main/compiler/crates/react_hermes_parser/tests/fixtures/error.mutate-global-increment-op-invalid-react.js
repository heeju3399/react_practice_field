let renderCount = 0;

function NoHooks() {
  renderCount++;
  return <div />;
}
