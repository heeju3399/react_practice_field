function f(y) {
  let x = y;
  return x + (x = 2) + x;
}
