function Component(p) {
  let x;
  const foo = () => {
    x = {};
  };
  foo();

  return x;
}
