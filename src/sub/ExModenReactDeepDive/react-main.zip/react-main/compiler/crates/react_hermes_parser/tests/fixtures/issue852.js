function Component(c) {
  let x = { c };
  mutate(x);
  let a = x;
  let b = a;
}
