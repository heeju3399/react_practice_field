// @enableEmitFreeze @instrumentForget

function useFoo(props) {
  return foo(props.x);
}
