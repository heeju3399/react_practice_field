function Component({ a = 2 }) {
  return a;
}
