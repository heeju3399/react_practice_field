function Component(props) {
  return <xml:http protocol:version={props.version} />;
}
