function Component(props) {
  const x = [];
  <dif>{x}</dif>;
  const y = x.map((item) => item);
  return [x, y];
}
