function Component(props) {
  const x = [];
  debugger;
  x.push(props.value);
  return x;
}
