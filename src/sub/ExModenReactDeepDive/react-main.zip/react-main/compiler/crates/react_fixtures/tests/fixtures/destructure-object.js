function Component(a, b) {
  const {
    c,
    d,
    e: { e },
    f: { _f: f },
    g: {
      g: {
        g: { g, ...h },
      },
    },
    ...i
  } = a;
  return [c, d, e, f, g, h, i];
}
